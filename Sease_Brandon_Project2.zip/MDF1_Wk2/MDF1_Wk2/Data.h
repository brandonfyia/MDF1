//
//  Data.h
//  MDF1_Wk2
//
//  Created by Brandon Sease on 10/30/12.
//  Copyright (c) 2012 Brandon Sease. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Data : NSObject

-(NSArray*)getArray;

@end
