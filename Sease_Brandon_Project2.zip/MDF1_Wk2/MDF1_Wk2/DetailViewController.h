//
//  DetailViewController.h
//  MDF1_Wk2
//
//  Created by Brandon Sease on 10/30/12.
//  Copyright (c) 2012 Brandon Sease. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"



@interface DetailViewController : UIViewController <UITableViewDelegate>
{
    NSString *itemDetail;
    IBOutlet UITextView *textView;
}

@property(nonatomic, retain)NSString *itemDetails;

@end
